/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saitam.h
 *
 * @brief   This module defines SAI TAM (Telemetry And Monitoring) spec
 */

#if !defined (__SAITAM_H_)
#define __SAITAM_H_

#include <saitypes.h>

/**
 * @defgroup SAITAM SAI - Telemetry and monitoring specific API definitions
 *
 * @{
 */

/**
 * @brief TAM Statistic ID
 *
 * Identifies a specific counter within the SAI object hierarchy
 */
typedef enum _sai_tam_stat_attr_t
{
    /**
     * @brief Start of Attributes
     */
    SAI_TAM_STAT_ATTR_START,

    /**
     * @brief Monitored object id
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_BUFFER_POOL, SAI_OBJECT_TYPE_INGRESS_PRIORITY_GROUP, SAI_OBJECT_TYPE_QUEUE
     */
    SAI_TAM_STAT_ATTR_PARENT_ID = SAI_TAM_STAT_ATTR_START,

    /**
     * @brief Counter
     *
     * Example: SAI_INGRESS_PRIORITY_GROUP_STAT_CURR_OCCUPANCY_BYTES.
     *
     * @type sai_uint32_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     */
    SAI_TAM_STAT_ATTR_COUNTER_ID,

    /**
     * @brief End of Attributes
     */
    SAI_TAM_STAT_ATTR_END,

    /** Custom range base value */
    SAI_TAM_STAT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_TAM_STAT_ATTR_CUSTOM_RANGE_END

} sai_tam_stat_attr_t;

/**
 * @brief Create and return a TAM stat id object
 *
 * @param[out] tam_stat_id TAM stat id object
 * @param[in] switch_id Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_tam_stat_fn)(
        _Out_ sai_object_id_t *tam_stat_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Deletes a specified tam stat id object.
 *
 * @param[in] tam_stat_id TAM object to be removed.
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_tam_stat_fn)(
        _In_ sai_object_id_t tam_stat_id);

/**
 * @brief Set TAM stat id object attribute value(s).
 *
 * @param[in] tam_stat_id TAM stat id
 * @param[in] attr Attribute to set
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_tam_stat_attribute_fn)(
        _In_ sai_object_id_t tam_stat_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get values for specified TAM stat id attributes.
 *
 * @param[in] tam_stat_id TAM stat id object id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_tam_stat_attribute_fn)(
        _In_ sai_object_id_t tam_stat_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief TAM Statistic
 *
 * Identifies a specific counter within the SAI object hierarchy
 * and provides the current value of the counter.
 */
typedef struct _sai_tam_statistic_t
{
    /**
     * @brief Statistic ID
     *
     * @objects SAI_OBJECT_TYPE_TAM_STAT
     */
    sai_object_id_t statistic_id;

    /**
     * @brief Value
     */
    uint64_t value;

} sai_tam_statistic_t;

/**
 * @brief TAM Tracking Options
 */
typedef enum _sai_tam_tracking_mode_t
{
    /** Peak value tracking mode */
    SAI_TAM_TRACKING_MODE_PEAK,

    /** Current value tracking mode */
    SAI_TAM_TRACKING_MODE_CURRENT,

    /** Average value tracking mode */
    SAI_TAM_TRACKING_MODE_AVERAGE,

    /** Minimum value tracking mode */
    SAI_TAM_TRACKING_MODE_MINIMUM
} sai_tam_tracking_mode_t;

/**
 * @brief TAM Reporting Options
 */
typedef enum _sai_tam_reporting_mode_t
{
    /** Report tracking data in terms of bytes */
    SAI_TAM_REPORTING_MODE_BYTES,

    /** Report tracking data in percentages */
    SAI_TAM_REPORTING_MODE_PERCENTAGE,
} sai_tam_reporting_mode_t;

/**
 * @brief TAM Attributes.
 */
typedef enum _sai_tam_attr_t
{
    /**
     * @brief Start of Attributes
     */
    SAI_TAM_ATTR_START,

    /**
     * @brief Operational State for the Buffer Tracking
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_TAM_ATTR_BUFFER_TRACKING_ADMIN_STATE = SAI_TAM_ATTR_START,

    /**
     * @brief Statistics reporting mode.
     *
     * When not specified, reports in number of bytes (DEFAULT)
     *
     * @type sai_tam_reporting_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_TAM_REPORTING_MODE_BYTES
     */
    SAI_TAM_ATTR_BUFFER_REPORTING_MODE,

    /**
     * @brief Buffer Tracker Mode
     *
     * Specifies whether the Chip should track the peak values of the
     * buffers or current usage values (DEFAULT).
     *
     * @type sai_tam_tracking_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_TAM_TRACKING_MODE_CURRENT
     */
    SAI_TAM_ATTR_BUFFER_TRACKING_MODE,

    /**
     * @brief Buffers/Statistics for tracking using this object
     *
     * Specifies the Statistics/Types for tracking. If not specified, all
     * supported buffers are included for tracking (DEFAULT).
     *
     * A statistic can't be tracked by more than one TAM Objects.
     *
     * @type sai_object_list_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_STAT
     * @default empty
     */
    SAI_TAM_ATTR_TRACKING_OPTIONS,

    /**
     * @brief Default Transporter
     *
     * Provides a default snapshot transporter object for the Tracker.
     * When a snapshot is made, this transporter will be used
     * to 'copy' the data to the 'transporter-desired' location.
     *
     * In the absence of a transporter, the tracker will copy the
     * data to the local CPU transporter.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_TRANSPORTER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_TAM_ATTR_TRANSPORTER,

    /**
     * @brief Clear all Thresholds
     *
     * If this attribute is specified and set to true, then
     * the following actions take place for each of the created threshold objects
     * 1. The values specified via the SAI_TAM_THRESHOLD_ATTR_LEVEL attribute are
     *    removed
     * 2. Threshold monitoring is disabled
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_TAM_ATTR_CLEAR_ALL_THRESHOLDS,

    /**
     * @brief Total Number of counters supported
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_TAM_ATTR_TOTAL_NUM_STATISTICS,

    /**
     * @brief The latest Snapshot ID
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_TAM_SNAPSHOT
     */
    SAI_TAM_ATTR_LATEST_SNAPSHOT_ID,

    /**
     * @brief Maximum Number of snapshots that can be created.
     *
     * If the number of currently created snapshots already reach this limit, any
     * attempt to create more snapshots return error.
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_TAM_ATTR_MAX_NUM_SNAPSHOTS,

    /**
     * @brief Tam thresholds associated with this tam.
     *
     * @type sai_object_list_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_TAM_THRESHOLD
     */
    SAI_TAM_ATTR_THRESHOLD_LIST,

    /**
     * @brief End of Attributes
     */
    SAI_TAM_ATTR_END,

    /** Custom range base value */
    SAI_TAM_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_TAM_ATTR_CUSTOM_RANGE_END

} sai_tam_attr_t;

/**
 * @brief Create and return a TAM object
 *
 * This creates a TAM object in the driver for tracking the buffer usage.
 * Via the attributes, caller may indicate a preference for tracking of a
 * specific set of statistics/groups.
 *
 * @param[out] tam_id TAM object
 * @param[in] switch_id Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_tam_fn)(
        _Out_ sai_object_id_t *tam_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Deletes a specified tam object.
 *
 * Deleting a TAM object also deletes all associated snapshot and threshold objects.
 *
 * @param[in] tam_id TAM object to be removed.
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_tam_fn)(
        _In_ sai_object_id_t tam_id);

/**
 * @brief Set TAM attribute value(s).
 *
 * @param[in] tam_id TAM id
 * @param[in] attr Attribute to set
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_tam_attribute_fn)(
        _In_ sai_object_id_t tam_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get values for specified TAM attributes.
 *
 * @param[in] tam_id TAM object id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_tam_attribute_fn)(
        _In_ sai_object_id_t tam_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief TAM Threshold Breach Event notification
 */
typedef struct _sai_tam_threshold_breach_event_t
{
    /**
     * @brief Threshold ID
     */
    sai_object_id_t threshold_id;

    /**
     * @brief Snapshot Valid
     *
     * Indicates whether the tam_snapshot_id field points to a valid object.
     * is_snapshot_valid is set to false when the attribute
     * SAI_TAM_THRESHOLD_ATTR_SNAPSHOT_ON_BREACH is either unspecified or set
     * to false.
     */
    bool is_snapshot_valid;

    /**
     * @brief Snapshot Id
     *
     * This field is valid only when is_snapshot_valid is set to true.
     *
     * @objects SAI_OBJECT_TYPE_TAM_SNAPSHOT
     */
    sai_object_id_t tam_snapshot_id;

    /**
     * @brief Threshold / Statistic value for the breach event
     */
    uint64_t value;

} sai_tam_threshold_breach_event_t;

/**
 * @brief TAM event notification function
 *
 * Provides the callback function to be invoked upon a threshold breach.
 * In the absence of a callback function, the event will be ignored (DEFAULT)
 * If neither of callback nor transporter is provided, no snapshot is made.
 * If callback is required but SAI_TAM_THRESHOLD_ATTR_SNAPSHOT_ON_BREACH is
 * set to false, then the event data passed to the callback function will
 * have the field is_snapshot_valid set to false.
 *
 * @count data[count]
 *
 * @param[in] count Number of events
 * @param[in] data Pointer to TAM events data array
 */
typedef void (*sai_tam_event_notification_fn)(
        _In_ uint32_t count,
        _In_ sai_tam_threshold_breach_event_t *data);

/**
 * @brief TAM Threshold Attributes.
 */
typedef enum _sai_tam_threshold_attr_t
{
    /**
     * @brief Start of Attributes
     */
    SAI_TAM_THRESHOLD_ATTR_START,

    /**
     * @brief TAM Object
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM
     */
    SAI_TAM_THRESHOLD_ATTR_TAM_ID = SAI_TAM_THRESHOLD_ATTR_START,

    /**
     * @brief Statistic for this threshold
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_STAT
     */
    SAI_TAM_THRESHOLD_ATTR_STATISTIC,

    /**
     * @brief Threshold Level
     *
     * Breach level for this threshold in number of bytes If specified, a
     * threshold breach event will be recorded when the buffer usage goes
     * beyond the level.
     *
     * If not specified, then by default the threshold is created without any
     * level, which is effectively disabling the threshold monitoring for the
     * statistic.
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TAM_THRESHOLD_ATTR_LEVEL,

    /**
     * @brief Transporter Object
     *
     * Provides the snapshot transporter object for this threshold. When the
     * threshold is breached, this transporter will be used to 'copy' the data
     * to the 'transporter-desired' location.
     *
     * In the absence of a transporter, the tracker's default transporter will
     * be used.
     *
     * It may be noted that, Upon a breach, the 'snapshot' object is
     * automatically created (see below attribute), and it will not have a
     * separate transporter object. Instead, this transporter (or the tracker's
     * default transporter) is used.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_TRANSPORTER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_TAM_THRESHOLD_ATTR_TRANSPORTER,

    /**
     * @brief Snapshot on breach
     *
     * Take a snapshot upon a threshold breach.
     * When this attribute is specified and set to true, Snapshots are
     * automatically created upon the threshold breach.
     * Otherwise, a snapshot is not created.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_TAM_THRESHOLD_ATTR_SNAPSHOT_ON_BREACH,

    /**
     * @brief Buffers/Statistics for inclusion in the snapshot
     *
     * Specifies the Statistics/Types for the snapshot.
     * If not specified, all buffers tracked by
     * the associated TAM object are included in the snapshot.
     * When specified, the buffers requested for snapshot must be within the set
     * tracked by the associated TAM object.
     *
     * @type sai_object_list_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_STAT
     * @default empty
     */
    SAI_TAM_THRESHOLD_ATTR_SNAPSHOT_STATS,

    /**
     * @brief End of Attributes
     */
    SAI_TAM_THRESHOLD_ATTR_END,

    /** Custom range base value */
    SAI_TAM_THRESHOLD_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_TAM_THRESHOLD_ATTR_CUSTOM_RANGE_END

} sai_tam_threshold_attr_t;

/**
 * @brief Create and return a threshold object
 *
 * This creates a threshold in the hardware with the associated statistic
 * passed via the attributes.
 *
 * @param[out] tam_threshold_id Threshold object
 * @param[in] switch_id Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Preferences for creating a threshold
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_tam_threshold_fn)(
        _Out_ sai_object_id_t *tam_threshold_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Deletes a specified threshold object.
 *
 * @param[in] tam_threshold_id Threshold object to be removed.
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_tam_threshold_fn)(
        _In_ sai_object_id_t tam_threshold_id);

/**
 * @brief Set threshold attribute value(s).
 *
 * @param[in] tam_threshold_id Threshold object id
 * @param[in] attr Attribute to set
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_tam_threshold_attribute_fn)(
        _In_ sai_object_id_t tam_threshold_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get values for specified threshold attributes.
 *
 * @param[in] tam_threshold_id Threshold object id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_tam_threshold_attribute_fn)(
        _In_ sai_object_id_t tam_threshold_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief TAM Snapshot Attributes.
 */
typedef enum _sai_tam_snapshot_attr_t
{
    /**
     * @brief Start of Attributes
     */
    SAI_TAM_SNAPSHOT_ATTR_START,

    /**
     * @brief TAM Object for this snapshot
     *
     * Specifies the TAM object for this snapshot.
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM
     */
    SAI_TAM_SNAPSHOT_ATTR_TAM_ID = SAI_TAM_SNAPSHOT_ATTR_START,

    /**
     * @brief Buffers/Statistics for inclusion in snapshot
     *
     * Specifies the Statistics/Types for a snapshot.
     * If not specified, all buffers tracked by
     * the associated TAM object are included in the snapshot. (DEFAULT)
     * When specified, the buffers requested for snapshot must be within the set
     * tracked by the associated TAM object.
     *
     * @type sai_object_list_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_STAT
     * @default empty
     */
    SAI_TAM_SNAPSHOT_ATTR_STAT_TYPE,

    /**
     * @brief Transporter Object
     *
     * Provides the snapshot transporter object for this snapshot.
     * When the snapshot is made, this transporter will be used
     * to 'copy' the data to the 'transporter-desired' location.
     * In the absence of a transporter, the tracker's default transporter
     * will be used (DEFAULT).
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_TRANSPORTER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_TAM_SNAPSHOT_ATTR_TRANSPORTER,

    /**
     * @brief End of Attributes
     */
    SAI_TAM_SNAPSHOT_ATTR_END,

    /** Custom range base value */
    SAI_TAM_SNAPSHOT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_TAM_SNAPSHOT_ATTR_CUSTOM_RANGE_END

} sai_tam_snapshot_attr_t;

/**
 * @brief Create and return a snapshot object
 *
 * This creates a snapshot in the hardware and copies the snapshot data
 * into the driver. Via the attributes, caller may indicate a preference
 * for snapshot of a specific set of statistics/groups.
 *
 * @param[out] tam_snapshot_id Snapshot object
 * @param[in] switch_id Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_tam_snapshot_fn)(
        _Out_ sai_object_id_t *tam_snapshot_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Deletes a specified snapshot object and free driver memory.
 *
 * @param[in] tam_snapshot_id Snapshot object to be removed.
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_tam_snapshot_fn)(
        _In_ sai_object_id_t tam_snapshot_id);

/**
 * @brief Set Snapshot attribute value(s).
 *
 * @param[in] tam_snapshot_id Snapshot object id
 * @param[in] attr Attribute to set
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_tam_snapshot_attribute_fn)(
        _In_ sai_object_id_t tam_snapshot_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get values for specified Snapshot attributes.
 *
 * @param[in] tam_snapshot_id Snapshot object id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_tam_snapshot_attribute_fn)(
        _In_ sai_object_id_t tam_snapshot_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Obtain the values for all statistics from a snapshot.
 *
 * Attribute list must supply sufficient memory for statistics
 * as specified for the snapshot object, which may be all statistics
 * supported by the associated tam object.
 *
 * @param[in] tam_snapshot_id Snapshot object id
 * @param[inout] number_of_counters Number of statistics (required/provided)
 * @param[inout] statistics Statistics (allocated/provided)
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_tam_snapshot_stats_fn)(
        _In_ sai_object_id_t tam_snapshot_id,
        _Inout_ uint32_t *number_of_counters,
        _Inout_ sai_tam_statistic_t *statistics);

/**
 * @brief TAM type of snapshot transport
 */
typedef enum _sai_tam_transporter_type_t
{
    /** Transport local, to the CPU */
    SAI_TAM_TRANSPORTER_TYPE_LOCAL,

    /** Transport remote, to a remote monitoring client */
    SAI_TAM_TRANSPORTER_TYPE_REMOTE,

} sai_tam_transporter_type_t;

/**
 * @brief TAM Snapshot Transporter Attributes
 */
typedef enum _sai_tam_transporter_attr_t
{
    /**
     * @brief Start of Attributes
     */
    SAI_TAM_TRANSPORTER_ATTR_START,

    /**
     * @brief Transporter Type
     *
     * If this attribute value is unspecified the local transporter is used.
     *
     * @type sai_tam_transporter_type_t
     * @flags CREATE_AND_SET
     * @default SAI_TAM_TRANSPORTER_TYPE_LOCAL
     */
    SAI_TAM_TRANSPORTER_ATTR_TYPE = SAI_TAM_TRANSPORTER_ATTR_START,

    /**
     * @brief Maximum size beyond which it will be truncated.
     *
     * If this attribute value is zero or unspecified, snapshots are not
     * truncated while transporting. (DEFAULT)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TAM_TRANSPORTER_ATTR_MAX_SNAPSHOT_SIZE,

    /**
     * @brief Mirroring session object defining the remote transport capabilities.
     *
     * If this attribute is unspecified, Local CPU Transport is used (DEFAULT).
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MIRROR_SESSION
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_TAM_TRANSPORTER_ATTR_MONITOR_ID,

    /**
     * @brief End of Attributes
     */
    SAI_TAM_TRANSPORTER_ATTR_END,

    /** Custom range base value */
    SAI_TAM_TRANSPORTER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_TAM_TRANSPORTER_ATTR_CUSTOM_RANGE_END

} sai_tam_transporter_attr_t;

/**
 * @brief Create and return a Transporter object
 *
 * This creates a transport object for copying the snapshot data
 * to the desired location.
 *
 * @param[out] tam_transporter_id Transporter object
 * @param[in] switch_id Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_tam_transporter_fn)(
        _Out_ sai_object_id_t *tam_transporter_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Deletes a specified Transporter object.
 *
 * @param[in] tam_transporter_id Transporter object to be removed.
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_tam_transporter_fn)(
        _In_ sai_object_id_t tam_transporter_id);

/**
 * @brief Set TAM Transporter attribute value(s).
 *
 * @param[in] tam_transporter_id Transporter object id
 * @param[in] attr Attribute to set
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_tam_transporter_attribute_fn)(
        _In_ sai_object_id_t tam_transporter_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get values for specified Transporter attributes.
 *
 * @param[in] tam_transporter_id Transporter object id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_tam_transporter_attribute_fn)(
        _In_ sai_object_id_t tam_transporter_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

typedef struct _sai_tam_api_t
{
    sai_create_tam_fn                       create_tam;
    sai_remove_tam_fn                       remove_tam;
    sai_set_tam_attribute_fn                set_tam_attribute;
    sai_get_tam_attribute_fn                get_tam_attribute;
    sai_create_tam_stat_fn                  create_tam_stat;
    sai_remove_tam_stat_fn                  remove_tam_stat;
    sai_set_tam_stat_attribute_fn           set_tam_stat_attribute;
    sai_get_tam_stat_attribute_fn           get_tam_stat_attribute;
    sai_create_tam_threshold_fn             create_tam_threshold;
    sai_remove_tam_threshold_fn             remove_tam_threshold;
    sai_set_tam_threshold_attribute_fn      set_tam_threshold_attribute;
    sai_get_tam_threshold_attribute_fn      get_tam_threshold_attribute;
    sai_create_tam_snapshot_fn              create_tam_snapshot;
    sai_remove_tam_snapshot_fn              remove_tam_snapshot;
    sai_set_tam_snapshot_attribute_fn       set_tam_snapshot_attribute;
    sai_get_tam_snapshot_attribute_fn       get_tam_snapshot_attribute;
    sai_get_tam_snapshot_stats_fn           get_tam_snapshot_stats;
    sai_create_tam_transporter_fn           create_tam_transporter;
    sai_remove_tam_transporter_fn           remove_tam_transporter;
    sai_set_tam_transporter_attribute_fn    set_tam_transporter_attribute;
    sai_get_tam_transporter_attribute_fn    get_tam_transporter_attribute;
} sai_tam_api_t;

/**
 * @}
 */
#endif /** __SAITAM_H_ */
